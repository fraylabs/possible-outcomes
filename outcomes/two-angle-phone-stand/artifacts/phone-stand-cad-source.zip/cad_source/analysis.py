"""Rigid-body statics for tapping: tip-over and sliding thresholds. Calculations only, not measurements."""
import json, math, os, sys
import cadquery as cq
import stand as S
from params import *

OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
G = 9.81e-3  # N per g
PHONES = {"large 80x168x11, 240 g": (PHONE_W_MAX, PHONE_T_MAX, 168.0, 240.0),
          "small 65x140x7, 140 g": (PHONE_W_MIN, PHONE_T_MIN, 140.0, 140.0)}
FILL = {"100% infill": 1.0, "est. 50% of solid mass": 0.5}
MU_PLA = 0.3  # assumption for PLA on a smooth desk; must be measured

base = S.base()
cradle = S.cradle_local()
mb_solid = base.val().Volume() * PLA_DENSITY
mc_solid = cradle.val().Volume() * PLA_DENSITY
cb = base.val().Center()
res = {"assumptions": {"mu": MU_PLA, "tap_direction": "normal to screen, into the screen",
                       "phones": list(PHONES), "mass_cases": FILL}, "cases": []}

for pos, ang in (("video", ANGLE_VIDEO), ("reading", ANGLE_READING)):
    o = S.LAYOUT[pos]
    cc = S.place(cradle, ang, o).val().Center()
    n, u = S.frame(ang)
    for pn, (w, t, L, mp) in PHONES.items():
        pc = S.to_world((-t / 2, L / 2), ang, o)
        for fname, k in FILL.items():
            masses = [(mb_solid * k, cb.y, cb.z), (mc_solid * k, cc.y, cc.z), (mp, pc[0], pc[1])]
            W = sum(m for m, _, _ in masses) * G
            yE = BASE_D  # rear edge: tipping-back pivot
            M_rest = sum(m * G * (yE - y) for m, y, _ in masses)
            ycg = sum(m * y for m, y, _ in masses) / sum(m for m, _, _ in masses)
            row = {"position": pos, "angle": ang, "phone": pn, "mass_case": fname,
                   "total_mass_g": round(W / G, 1), "cg_y_mm": round(ycg, 1),
                   "cg_inside_footprint": 0 < ycg < BASE_D, "taps": []}
            for frac in (0.25, 0.5, 0.75, 0.95):
                P = S.to_world((-t, frac * L), ang, o)
                Fy, Fz = n  # unit force into the screen
                ry, rz = P[0] - yE, P[1] - 0.0
                m_per_N = ry * Fz - rz * Fy  # moment about rear edge (negative = tips back)
                F_tip = M_rest / -m_per_N if m_per_N < 0 else float("inf")
                # sliding: F*sin(ang) <= mu*(W + F*cos(ang))
                denom = math.sin(math.radians(ang)) - MU_PLA * math.cos(math.radians(ang))
                F_slide = MU_PLA * W / denom if denom > 0 else float("inf")
                mu_1N = math.sin(math.radians(ang)) / (W + math.cos(math.radians(ang)))
                row["taps"].append({"tap_at_frac_of_phone_height": frac, "tap_height_above_desk": round(P[1], 1),
                                    "tip_back_force_N": round(F_tip, 2), "slide_force_N_mu0.3": round(F_slide, 2),
                                    "mu_needed_for_1N_tap": round(mu_1N, 2)})
            res["cases"].append(row)

# tongue root bending, worst case: large phone, reading angle, 2 N tap at 95% height (hand calc)
ang = ANGLE_READING; o = S.LAYOUT["reading"]; n, u = S.frame(ang)
w, t, L, mp = PHONES["large 80x168x11, 240 g"]
root = S.to_world((PLATE_T / 2, -LEDGE_T), ang, o)
pc = S.to_world((-t / 2, L / 2), ang, o)
P = S.to_world((-t, 0.95 * L), ang, o)
M = mp * G * (pc[0] - root[0]) + 2.0 * abs((P[0] - root[0]) * n[1] - (P[1] - root[1]) * n[0])
Z = CRADLE_W * PLATE_T ** 2 / 6
res["tongue_root"] = {"moment_Nmm": round(M, 1), "section_modulus_mm3": round(Z, 1),
                      "bending_stress_MPa": round(M / Z, 2),
                      "note": "hand calc, full-width tongue, load in the print layer plane; not a strength claim"}
# ledge cantilever (phone weight + 2 N tap component along the backrest onto the ledge)
F_ledge = mp * G * math.sin(math.radians(ang)) + 2.0
Mz = F_ledge * POCKET / 2
Zl = CRADLE_W * LEDGE_T ** 2 / 6
res["ledge_root"] = {"force_N": round(F_ledge, 2), "moment_Nmm": round(Mz, 1), "bending_stress_MPa": round(Mz / Zl, 3)}
res["masses_g_100pct"] = {"base": round(mb_solid, 1), "cradle": round(mc_solid, 1)}

with open(os.path.join(OUT, "analysis.json"), "w") as f:
    json.dump(res, f, indent=1)
for r in res["cases"]:
    print(r["position"], r["phone"], r["mass_case"], r["total_mass_g"], "g cg_y", r["cg_y_mm"],
          [(x["tap_at_frac_of_phone_height"], x["tip_back_force_N"], x["slide_force_N_mu0.3"]) for x in r["taps"]])
print("tongue", res["tongue_root"]); print("ledge", res["ledge_root"])
