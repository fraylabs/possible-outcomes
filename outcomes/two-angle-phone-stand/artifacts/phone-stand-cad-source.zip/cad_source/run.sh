#!/bin/bash
set -e
[ -x /tmp/v/bin/python ] || (python3 -m venv /tmp/v && /tmp/v/bin/pip install -q cadquery trimesh shapely matplotlib manifold3d rtree scipy networkx)
cd src
/tmp/v/bin/python build.py ../out 2>&1 | grep -v "^Warning"
/tmp/v/bin/python analysis.py ../out
/tmp/v/bin/python render.py ../out
rm -rf ../out/cad_source && mkdir -p ../out/cad_source && cp *.py ../run.sh ../out/cad_source/
