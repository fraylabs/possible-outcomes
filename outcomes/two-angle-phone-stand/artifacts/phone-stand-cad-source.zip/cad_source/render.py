"""Shaded matplotlib renders from world-position STL meshes."""
import os, sys, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import trimesh

OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
M = os.path.join(OUT, "mesh_world")
R = os.path.join(OUT, "renders"); os.makedirs(R, exist_ok=True)
LIGHT = np.array([-0.4, -0.7, 0.6]); LIGHT /= np.linalg.norm(LIGHT)


def add(ax, fn, color, alpha=1.0, view=None):
    m = trimesh.load(os.path.join(M, fn))
    v, f = trimesh.remesh.subdivide_to_size(m.vertices, m.faces, max_edge=3.0)
    m = trimesh.Trimesh(v, f, process=False)
    sh = 0.35 + 0.65 * np.clip(m.face_normals @ LIGHT, 0, 1)
    cols = np.clip(np.outer(sh, color), 0, 1)
    cols = np.hstack([cols, np.full((len(cols), 1), alpha)])
    return m.triangles, cols, m.bounds


def fig(name, items, elev=22, azim=-55, title="", ortho=False, lim=None):
    f = plt.figure(figsize=(8, 8), dpi=130)
    ax = f.add_subplot(111, projection="3d")
    if ortho:
        ax.set_proj_type("ortho")
    got = [add(ax, *it) for it in items]
    bs = [g[2] for g in got]
    # one collection so faces from all parts are depth-sorted together
    pc = Poly3DCollection(np.concatenate([g[0] for g in got]), facecolors=np.concatenate([g[1] for g in got]),
                          edgecolors="none", linewidths=0)
    ax.add_collection3d(pc)
    lo = np.min([b[0] for b in bs], axis=0); hi = np.max([b[1] for b in bs], axis=0)
    if lim is not None:
        lo, hi = np.array(lim[0]), np.array(lim[1])
    c = (lo + hi) / 2; r = (hi - lo).max() / 2 * 1.02
    ax.set_xlim(c[0] - r, c[0] + r); ax.set_ylim(c[1] - r, c[1] + r); ax.set_zlim(c[2] - r, c[2] + r)
    ax.set_box_aspect((1, 1, 1))
    ax.view_init(elev=elev, azim=azim)
    ax.set_xlabel("X mm"); ax.set_ylabel("Y mm"); ax.set_zlabel("Z mm")
    ax.set_title(title)
    f.tight_layout(); f.savefig(os.path.join(R, name)); plt.close(f)


BASE = (0.30, 0.50, 0.80); CR = (0.95, 0.60, 0.25); PH = (0.25, 0.25, 0.25); PL = (0.85, 0.15, 0.15)
for pos, ang in (("video", 70), ("reading", 55)):
    fig(f"assembled_{pos}.png", [("base.stl", BASE), (f"cradle_{pos}.stl", CR)],
        title=f"Assembled - {pos} position ({ang} deg)", azim=-125)
    fig(f"in_use_{pos}.png", [("base.stl", BASE), (f"cradle_{pos}.stl", CR), (f"plug_{pos}.stl", PL),
                               (f"phone_{pos}.stl", PH, 0.35)],
        title=f"{pos} position with 80x168x11 phone envelope + cable plug keep-out", azim=-125)
    fig(f"side_{pos}.png", [("base.stl", BASE), (f"cradle_{pos}.stl", CR), (f"plug_{pos}.stl", PL),
                             (f"phone_{pos}.stl", PH, 0.35)],
        elev=0, azim=0, ortho=True, title=f"Side view (from +X) - {pos} {ang} deg")
fig("exploded.png", [("base.stl", BASE), ("cradle_exploded.stl", CR)], title="Exploded - cradle lifted out along tongue axis",
    azim=-125)
fig("base_top.png", [("base.stl", BASE)], elev=60, azim=-120, title="SB-01 Base: two sockets (front 55 deg, rear 70 deg), cable notch")
fig("base_under.png", [("base.stl", BASE)], elev=-50, azim=-120, title="SB-01 Base underside: cable channel to rear")
print(sorted(os.listdir(R)))
