"""Export STEP/STL and run self-checks. Writes ./out and out/checks.json."""
import json, math, os, sys
import cadquery as cq
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
import trimesh
import stand as S
from params import *

OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
for d in ("step", "stl", "mesh_world"):
    os.makedirs(os.path.join(OUT, d), exist_ok=True)

TOL = 1e-3  # mm^3 volume treated as zero interference


def vol(w):
    return sum(s.Volume() for s in w.solids().vals()) if w.solids().size() else 0.0


def inter_vol(a, b):
    try:
        return vol(a.intersect(b))
    except Exception:
        return float("nan")


def dist(a, b):
    d = BRepExtrema_DistShapeShape(a.val().wrapped, b.val().wrapped)
    d.Perform()
    return d.Value()


def bbox(w):
    bb = w.val().BoundingBox() if w.solids().size() == 1 else cq.Compound.makeCompound(w.solids().vals()).BoundingBox()
    return [round(v, 2) for v in (bb.xmin, bb.ymin, bb.zmin, bb.xmax, bb.ymax, bb.zmax)]


R = {"layout": {k: [round(v, 2) for v in o] for k, o in S.LAYOUT.items()}, "checks": []}


def check(name, ok, value, need):
    R["checks"].append({"check": name, "pass": bool(ok), "value": value, "requirement": need})
    print(("PASS " if ok else "FAIL ") + name, value, "|", need)


base = S.base()
cradle = S.cradle_local()
parts = {"SB-01_Base": base, "SB-02_Cradle": cradle}

# 1 valid solids, mass
R["parts"] = {}
for nm, p in parts.items():
    ok = all(s.isValid() for s in p.solids().vals()) and p.solids().size() == 1
    v = vol(p)
    R["parts"][nm] = {"volume_mm3": round(v, 1), "mass_g_100pct": round(v * PLA_DENSITY, 1), "bbox_model": bbox(p)}
    check(f"{nm} is one valid closed solid", ok, p.solids().size(), "1 valid solid")

# 2 positions: interference, intended contact, footprint, angle
for pos, ang in (("video", ANGLE_VIDEO), ("reading", ANGLE_READING)):
    o = S.LAYOUT[pos]
    c = S.place(cradle, ang, o)
    iv = inter_vol(base, c)
    check(f"{pos}: base/cradle interference", iv < TOL, round(iv, 4), "< 0.001 mm^3")
    d = dist(base, c)
    check(f"{pos}: tongue tip seated on socket floor (contact)", d < 1e-3, round(d, 4), "distance 0")
    n, u = S.frame(ang)
    push = c.translate((0, -0.05 * u[0], -0.05 * u[1]))
    area = inter_vol(base, push) / 0.05
    check(f"{pos}: floor contact area (positive stop)", area > 0.5 * CRADLE_W * PLATE_T,
          round(area, 1), f"> {0.5 * CRADLE_W * PLATE_T:.0f} mm^2 (half the tongue tip)")
    # side wall clearance (cradle shifted sideways must not hit until ~clearance)
    for dx in (SOCKET_CLR * 0.8,):
        iv2 = inter_vol(base, c.translate((dx, 0, 0)))
        check(f"{pos}: tongue free to {dx:.2f} mm sideways", iv2 < TOL, round(iv2, 4), "no contact within clearance")
    iv3 = inter_vol(base, c.translate((0.6, 0, 0)))
    check(f"{pos}: socket end wall stops sideways slide", iv3 > TOL, round(iv3, 3), "contact by 0.6 mm shift")
    # tongue engagement depth below base top
    tip = -LEDGE_T - TONGUE_L
    zt = S.to_world((0, tip), ang, o)[1]
    zroot = S.to_world((0, -LEDGE_T), ang, o)[1]
    eng = min(BASE_H, zroot) - zt
    check(f"{pos}: tongue engagement (vertical, front face)", eng / math.sin(math.radians(ang)) >= 8,
          round(eng / math.sin(math.radians(ang)), 1), ">= 8 mm along tongue")
    # plate angle measured from placed geometry
    p0 = S.to_world((0, 0), ang, o); p1 = S.to_world((0, PLATE_L), ang, o)
    meas = math.degrees(math.atan2(p1[1] - p0[1], p1[0] - p0[0]))
    check(f"{pos}: backrest angle", abs(meas - ang) < 0.01, round(meas, 2), f"{ang} deg from horizontal")
    # footprint
    bb_all = cq.Compound.makeCompound([base.val(), c.val()]).BoundingBox()
    fx, fy = bb_all.xlen, bb_all.ylen
    check(f"{pos}: stand footprint", fx < 90 and fy < 90, [round(fx, 2), round(fy, 2)], "< 90 x 90 mm")
    R.setdefault("assembled_bbox", {})[pos] = bbox(cq.Workplane().add(cq.Compound.makeCompound([base.val(), c.val()])))
    # phones and plug keep-out
    for (w, t, L) in ((PHONE_W_MIN, PHONE_T_MIN, 140.0), (PHONE_W_MAX, PHONE_T_MAX, 168.0), (PHONE_W_MIN, PHONE_T_MAX, 150.0)):
        ph = S.place(S.phone_local(w, t, L), ang, o)
        ivc = inter_vol(ph, c); ivb = inter_vol(ph, base)
        dc = dist(ph, c)
        check(f"{pos}: phone {w:.0f}x{t:.0f}x{L:.0f} fits (no overlap with cradle/base)", ivc < TOL and ivb < TOL,
              [round(ivc, 4), round(ivb, 4)], "0 overlap")
        check(f"{pos}: phone {w:.0f}x{t:.0f} rests on ledge + backrest", dc < 1e-3, round(dc, 4), "touching")
    plug = S.place(S.plug_local(), ang, o)
    ivp = inter_vol(plug, c) + inter_vol(plug, base)
    check(f"{pos}: cable plug keep-out clear ({PLUG_W:.0f} x {PLUG_A[1]-PLUG_A[0]:.1f} x {PLUG_L:.0f})", ivp < TOL, round(ivp, 4), "0 overlap")
    zmin_plug = plug.val().BoundingBox().zmin
    check(f"{pos}: plug keep-out above desk", zmin_plug > 1.0, round(zmin_plug, 2), "> 1 mm")
    R.setdefault("origin", {})[pos] = [round(v, 2) for v in o]
    R.setdefault("lip_top_above_desk", {})[pos] = round(S.to_world((-POCKET, LIP_H), ang, o)[1], 1)
    R.setdefault("ledge_top_above_desk", {})[pos] = round(o[1], 1)
    # world meshes for rendering
    cq.exporters.export(c, os.path.join(OUT, "mesh_world", f"cradle_{pos}.stl"), tolerance=0.05, angularTolerance=0.1)
    cq.exporters.export(ph, os.path.join(OUT, "mesh_world", f"phone_{pos}.stl"))
    cq.exporters.export(S.place(S.phone_local(PHONE_W_MAX, PHONE_T_MAX, 168.0), ang, o), os.path.join(OUT, "mesh_world", f"phone_{pos}.stl"))
    cq.exporters.export(plug, os.path.join(OUT, "mesh_world", f"plug_{pos}.stl"))

# wall between sockets
s_r = S.place(S.socket_local(), ANGLE_READING, S.LAYOUT["reading"])
s_v = S.place(S.socket_local(), ANGLE_VIDEO, S.LAYOUT["video"])
blk = cq.Workplane("XY").box(BASE_W, BASE_D, BASE_H, centered=(True, False, False))
dw = dist(s_r.intersect(blk), s_v.intersect(blk))
check("wall between the two sockets", dw >= WALL_MIN - 0.05, round(dw, 2), f">= {WALL_MIN} mm")
bbr = s_r.intersect(blk).val().BoundingBox()
check("wall in front of reading socket", bbr.ymin >= WALL_MIN - 0.05, round(bbr.ymin, 2), f">= {WALL_MIN} mm")
floor_z = min(s_r.intersect(blk).val().BoundingBox().zmin, s_v.intersect(blk).val().BoundingBox().zmin)
check("material under socket floors", floor_z >= 3, round(floor_z, 2), ">= 3 mm")

# exports: per-part STEP, assembled & exploded STEP (named), STL print-oriented
for nm, p in parts.items():
    cq.exporters.export(p, os.path.join(OUT, "step", f"{nm}.step"))
for pos, ang in (("video", ANGLE_VIDEO), ("reading", ANGLE_READING)):
    a = cq.Assembly(name=f"PhoneStand_{pos}")
    a.add(base, name="SB-01_Base", color=cq.Color(0.25, 0.45, 0.75))
    a.add(S.place(cradle, ang, S.LAYOUT[pos]), name="SB-02_Cradle", color=cq.Color(0.9, 0.55, 0.2))
    a.save(os.path.join(OUT, "step", f"PhoneStand_assembled_{pos}.step"))
b2, c2 = S.exploded("video")
a = cq.Assembly(name="PhoneStand_exploded")
a.add(b2, name="SB-01_Base", color=cq.Color(0.25, 0.45, 0.75))
a.add(c2, name="SB-02_Cradle", color=cq.Color(0.9, 0.55, 0.2))
a.save(os.path.join(OUT, "step", "PhoneStand_exploded.step"))
cq.exporters.export(base, os.path.join(OUT, "mesh_world", "base.stl"), tolerance=0.05, angularTolerance=0.1)
cq.exporters.export(c2, os.path.join(OUT, "mesh_world", "cradle_exploded.stl"), tolerance=0.05, angularTolerance=0.1)

# re-import STEPs to confirm they are readable and valid
for f in sorted(os.listdir(os.path.join(OUT, "step"))):
    w = cq.importers.importStep(os.path.join(OUT, "step", f))
    sol = w.solids().vals()
    check(f"STEP re-import {f}", len(sol) >= 1 and all(s.isValid() for s in sol), len(sol), "valid solids")

# print-oriented STL + build volume + overhang scan
R["print"] = {}
for nm in parts:
    po = S.print_oriented(nm)
    fn = os.path.join(OUT, "stl", f"{nm}_print.stl")
    cq.exporters.export(po, fn, tolerance=0.02, angularTolerance=0.1)
    bb = po.val().BoundingBox()
    dims = [round(bb.xlen, 2), round(bb.ylen, 2), round(bb.zlen, 2)]
    check(f"{nm} inside build volume (print orientation)", bb.xlen <= BED[0] and bb.ylen <= BED[1] and bb.zlen <= BED[2]
          and bb.zmin >= -0.05, dims, f"<= {BED}")
    m = trimesh.load(fn)
    check(f"{nm} STL watertight", bool(m.is_watertight), bool(m.is_watertight), "watertight")
    nz = m.face_normals[:, 2]
    zc = m.triangles_center[:, 2]
    down = (nz < -math.sin(math.radians(47))) & (zc > 0.2)  # overhang angle from vertical = asin(-nz)
    flat = down & (nz < -0.999)
    steep = down & ~flat
    area_flat = float(m.area_faces[flat].sum())
    area_steep = float(m.area_faces[steep].sum())
    zl = sorted(set(round(float(z), 1) for z in zc[flat]))
    R["print"][nm] = {"dims": dims, "overhang_flat_area_mm2": round(area_flat, 1), "overhang_flat_z": zl,
                      "overhang_steep_area_mm2": round(area_steep, 1), "faces": len(m.faces)}
    check(f"{nm} no sloped overhang steeper than 45deg (47deg allows STL facetting; flat bridges listed separately)", area_steep < 1.0, round(area_steep, 2),
          "< 1 mm^2")
    # bridge span: for flat down-facing faces, report the shortest bbox side of each connected region
    if flat.any():
        sub = m.submesh([flat.nonzero()[0]], append=True)
        spans = []
        for comp in sub.split(only_watertight=False):
            e = comp.bounds[1] - comp.bounds[0]
            spans.append({"z": round(float(comp.bounds[0][2]), 1), "size_xy": [round(float(e[0]), 1), round(float(e[1]), 1)],
                          "short_side": round(float(min(e[0], e[1])), 1), "long_side": round(float(max(e[0], e[1])), 1)})
        R["print"][nm]["bridges"] = spans
        mx = max(s["short_side"] for s in spans)
        check(f"{nm} flat overhang regions: largest short side", mx <= 20.0, mx,
              "<= 20 mm; each region's anchoring is reviewed in REPORT.md")

with open(os.path.join(OUT, "checks.json"), "w") as f:
    json.dump(R, f, indent=1)
print("FAILED:", [c["check"] for c in R["checks"] if not c["pass"]])
