"""Two-angle desk phone stand: SB-01 Base + SB-02 Cradle.

Frames
  World: X width (centred), Y depth (0 = front edge, + toward rear), Z up (0 = desk).
  Cradle local (a, b): a = across the backrest (0 = phone-side face, + toward rear),
  b = along the backrest (0 = ledge top, + up). Local a -> world Y, b -> world Z,
  then rotate about +X by (angle - 90) and move origin O to (y_O, z_O).
"""
import math
import cadquery as cq
from params import *


def cradle_profile_pts():
    a0, a1 = 0.0, PLATE_T
    lip_in, lip_out = -POCKET, -(POCKET + LIP_T)
    tip = -LEDGE_T - TONGUE_L
    return [
        (a1, tip), (a1, PLATE_L), (a0, PLATE_L), (a0, 0.0),
        (lip_in, 0.0), (lip_in, LIP_H), (lip_out, LIP_H), (lip_out, -LEDGE_T),
        (a0, -LEDGE_T), (a0, tip),
    ]


def cradle_local():
    """SB-02 Cradle in local frame (a->Y, b->Z), width along X."""
    body = (cq.Workplane("YZ").polyline(cradle_profile_pts()).close()
            .extrude(CRADLE_W / 2, both=True))
    body = body.edges("|X").edges(cq.selectors.BoxSelector(
        (-50, -1, PLATE_L - 0.1), (50, PLATE_T + 1, PLATE_L + 0.1))).fillet(EDGE_R)
    body = body.edges("|X").edges(cq.selectors.BoxSelector(
        (-50, -(POCKET + LIP_T) - 1, LIP_H - 0.1), (50, -POCKET + 1, LIP_H + 0.1))).fillet(1.2)
    slot = (cq.Workplane("XY").box(CABLE_SLOT_W, POCKET, LEDGE_T + 2, centered=(True, False, False))
            .translate((0, -POCKET, -LEDGE_T - 1)))
    return body.cut(slot)


def frame(angle):
    t = math.radians(angle)
    n = (math.sin(t), -math.cos(t))
    u = (math.cos(t), math.sin(t))
    return n, u


def to_world(pt, angle, origin):
    a, b = pt
    n, u = frame(angle)
    return (origin[0] + a * n[0] + b * u[0], origin[1] + a * n[1] + b * u[1])


def place(shape, angle, origin):
    return shape.rotate((0, 0, 0), (1, 0, 0), angle - 90).translate((0, origin[0], origin[1]))


def z_origin(angle):
    """Ledge underside lowest corner (a=PLATE_T, b=-LEDGE_T) sits LEDGE_GAP above the base top."""
    n, u = frame(angle)
    return BASE_H + LEDGE_GAP - (PLATE_T * n[1] + (-LEDGE_T) * u[1])


def socket_local():
    tip = -LEDGE_T - TONGUE_L
    h = 40.0
    return (cq.Workplane("XY")
            .box(CRADLE_W + 2 * SOCKET_CLR, PLATE_T + 2 * SOCKET_CLR, h, centered=(True, False, False))
            .translate((0, -SOCKET_CLR, tip)))


def socket_y_range(angle, origin):
    """World Y extent of the socket cavity below the base top (its 2-D profile is exact)."""
    tip = -LEDGE_T - TONGUE_L
    ys = []
    for a in (-SOCKET_CLR, PLATE_T + SOCKET_CLR):
        for b in (tip, tip + 0.0):
            ys.append(to_world((a, b), angle, origin)[0])
        # where each socket wall line crosses the base top plane
        n, u = frame(angle)
        y0, z0 = to_world((a, tip), angle, origin)
        s = (BASE_H - z0) / u[1]
        ys.append(y0 + s * u[0])
    return min(ys), max(ys)


def solve_layout():
    """Reading socket in front, video socket behind; walls >= WALL_MIN; lip inside footprint."""
    out = {}
    ar = ANGLE_READING
    zr = z_origin(ar)
    y = 0.0
    while True:
        lip_front = min(to_world(p, ar, (y, zr))[0] for p in [(-(POCKET + LIP_T), -LEDGE_T), (-(POCKET + LIP_T), LIP_H)])
        s0, s1 = socket_y_range(ar, (y, zr))
        if lip_front >= LIP_FRONT_MARGIN and s0 >= WALL_MIN:
            break
        y += 0.1
    out["reading"] = (round(y, 2), zr)
    av = ANGLE_VIDEO
    zv = z_origin(av)
    yv = y
    while True:
        v0, v1 = socket_y_range(av, (yv, zv))
        if v0 - s1 >= WALL_MIN:
            break
        yv += 0.1
    out["video"] = (round(yv, 2), zv)
    return out


LAYOUT = solve_layout()


def notch_depth():
    """Notch must clear the plug keep-out in both positions (+2 mm)."""
    ys = []
    for key, ang in (("reading", ANGLE_READING), ("video", ANGLE_VIDEO)):
        for a in PLUG_A:
            for b in (0.0, -PLUG_L):
                ys.append(to_world((a, b), ang, LAYOUT[key])[0])
    return max(ys) + 2.0


def base():
    """SB-01 Base: solid block with two angled tongue sockets and a cable notch + channel."""
    body = (cq.Workplane("XY").box(BASE_W, BASE_D, BASE_H, centered=(True, False, False))
            .edges("|Z").fillet(BASE_CORNER_R).faces(">Z").edges().chamfer(1.0)
            .faces("<Z").edges().chamfer(0.6))
    for key, ang in (("reading", ANGLE_READING), ("video", ANGLE_VIDEO)):
        body = body.cut(place(socket_local(), ang, LAYOUT[key]))
    nd = notch_depth()
    notch = cq.Workplane("XY").box(NOTCH_W, nd + 1, BASE_H + 2, centered=(True, False, False)).translate((0, -1, -1))
    chan = (cq.Workplane("XY").box(CHANNEL_W, BASE_D - nd + 4, CHANNEL_H + 1, centered=(True, False, False))
            .translate((0, nd - 2, -1)))
    return body.cut(notch).cut(chan)


def phone_local(w, t, L):
    return cq.Workplane("XY").box(w, t, L, centered=(True, False, False)).translate((0, -t, 0))


def plug_local():
    return (cq.Workplane("XY").box(PLUG_W, PLUG_A[1] - PLUG_A[0], PLUG_L, centered=(True, False, False))
            .translate((0, PLUG_A[0], -PLUG_L)))


PARTS = {"SB-01_Base": base, "SB-02_Cradle": cradle_local}


def assembly(position):
    ang = ANGLE_VIDEO if position == "video" else ANGLE_READING
    b = base()
    c = place(cradle_local(), ang, LAYOUT[position])
    return b, c


def exploded(position="video", lift=45.0):
    ang = ANGLE_VIDEO if position == "video" else ANGLE_READING
    n, u = frame(ang)
    o = LAYOUT[position]
    o2 = (o[0] + lift * u[0], o[1] + lift * u[1])
    return base(), place(cradle_local(), ang, o2)


def print_oriented(name):
    if name == "SB-01_Base":
        return base()  # flat on its underside
    # Cradle on its side: profile on the bed, width along print Z
    c = cradle_local().rotate((0, 0, 0), (0, 1, 0), 90)
    bb = c.val().BoundingBox()
    return c.translate((-bb.xmin, -bb.ymin, -bb.zmin))
