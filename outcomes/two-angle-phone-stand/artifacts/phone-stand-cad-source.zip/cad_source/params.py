"""Named design parameters for the two-angle desk phone stand. Units: mm, degrees, g."""

# --- angles (phone plane from horizontal) ---
ANGLE_VIDEO = 70.0      # video-call position (rear socket)
ANGLE_READING = 55.0    # reading position (front socket)

# --- phone envelope from the brief ---
PHONE_W_MIN, PHONE_W_MAX = 65.0, 80.0
PHONE_T_MAX = 11.0      # incl. case
PHONE_T_MIN = 7.0       # assumption: thinnest phone without case

# --- cradle (part SB-02) ---
CRADLE_W = 72.0         # width along X
PLATE_T = 5.0           # backrest / tongue thickness
PLATE_L = 90.0          # backrest height above ledge top
LEDGE_T = 6.0           # ledge thickness (under phone)
POCKET = 12.5           # plate face to lip inner face (11 mm phone + 1.5 clearance)
LIP_T = 3.0             # lip thickness
LIP_H = 6.0             # lip height above ledge top
TONGUE_L = 14.0         # tongue length below the ledge
CABLE_SLOT_W = 15.0     # cable slot through ledge (X)
EDGE_R = 2.0            # rounding on plate and lip tops

# --- base (part SB-01) ---
BASE_W = 88.0           # X
BASE_D = 88.0           # Y
BASE_H = 22.0           # block height (= socket entry plane)
BASE_CORNER_R = 6.0
SOCKET_CLR = 0.25       # per side, tongue thickness/width clearance
LEDGE_GAP = 1.0         # ledge underside above base top at its lowest point
WALL_MIN = 3.0          # min wall between/in front of sockets
LIP_FRONT_MARGIN = 1.0  # lip front stays this far behind base front
NOTCH_W = 18.0          # central cable notch (through, open to front)
CHANNEL_W = 8.0         # underside cable channel to rear
CHANNEL_H = 5.0

# --- cable plug keep-out (assumption: USB-C / Lightning plug + strain relief) ---
PLUG_W = 12.0
PLUG_A = (-9.0, -0.5)   # across phone thickness, plate face = 0, toward screen negative
PLUG_L = 30.0           # straight length below phone bottom before the cable can bend

# --- material / print ---
PLA_DENSITY = 1.24e-3   # g/mm^3
BED = (220.0, 220.0, 250.0)  # assumption: 220x220 bed, 250 Z
